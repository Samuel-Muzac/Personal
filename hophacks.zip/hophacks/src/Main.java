import java.util.Scanner;


public class Main {


  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);  // Create a Scanner object

    int option1 = main_menu(input);

    double option2;


    if (option1 != -1 ) {
      option2 = input_order(option1);

      while (option2 == 0) {
        option1 = main_menu(input);

        option2 = input_order(option1);

      }
      System.out.println("Final price is: $" + option2);

    } else {
      System.out.print("Goodbye");
    }


  }

  static int main_menu(Scanner input){
    System.out.println("Hello, where would you like to eat today");
    System.out.println("Enter 1 (&pizza) or 2(HoneyGrow). ");
    System.out.println("Enter -1 to exit");

    int option = input.nextInt();  // Read user input
    while (option > 2 || option < -1) {
      System.out.println("Please enter a valid input\n");
      System.out.println("Enter 1 (&pizza) or 2(Honeygrow).");
      option = input.nextInt();
    }
    return option;
  }

    static double input_order(int option) {

      Scanner choice = new Scanner(System.in);
      int picked_food;
      int picked_drink;
      Restuarantmenu order;


      if (option == 1) {//&pizza
        order = new Pizza();
      } else if (option == 2) {//honeygrow
        order = new HoneyGrow();
      } else {
        return 0;
      }

      //print the menu
       order.print_menu();
       System.out.println("Press 0 to return to main menu");

       System.out.println("Pick option for food:");
       option = choice.nextInt();

       if (option == 0) {
         return 0;//return to menu
       } else {
         picked_food = option;
       }

       while (picked_food > 3 || picked_food < 0) {
         System.out.print("Enter a valid option");
         order.print_menu();
         System.out.println("Pick option for food:");
         option = choice.nextInt();

         if (option == 0) {
           return 0;//return to menu
         } else {
           picked_food = option;
         }
       }


       System.out.println("Pick option for drink:");
       option = choice.nextInt();

       if (option == 0) {
         return 0;//return to menu
       } else {
         picked_drink = option;
       }

       while (picked_drink > 5 || picked_drink < 4) {
         System.out.print("Enter a valid option");
         order.print_menu();
         System.out.println("Pick option for drink:");
         option = choice.nextInt();

         if (option == 0) {
           return 0;//return to menu
         } else {
           picked_drink = option;
         }
       }

       return order.get_food_item(picked_food) +
               order.get_drink_item(picked_drink);

     }
  }


