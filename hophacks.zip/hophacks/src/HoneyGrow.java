/* Class for honeygrow that lists its menu and prices
*Honeygrow serves stirfry food
 */

public class HoneyGrow implements Restuarantmenu {
  @Override
  public void print_menu() {
    System.out.println("      Entrees      ");
    System.out.println("**Press the number associated with the item");
    System.out.println("1. Garlic Butter Chicken: Freshly made egg white noodles, " +
            "roasted chicken, snow peas, scallions," +
            " mushrooms, toasted sesame seeds, " +
            "chili crisps and our garlic butter sauce ($11.85)");
    System.out.println("2. Red Coconut Curry: Rice noodles, roasted tofu, " +
            "pineapples, jalapeños, carrots, scallions, " +
            "cilantro, and our red coconut curry sauce. ($11.65");
    System.out.println("3. Spicy Garlic: Freshly made egg white noodles, " +
            "roasted chicken, bell peppers, broccoli, " +
            "red onions, pineapples, parsley, spicy garlic sauce ($12.85)");
    System.out.println("      Drinks      ");
    System.out.println("4. Tangerine Passion Fruit Juice ($2.99)");
    System.out.println("5. Mexican Coca Cola");
  }

  @Override
  public double get_food_item(int option) {
    if (option == 1 || option == 3) {
      return 11.85;
    } else {
      return 11.65;
    }
  }

  @Override
  public double get_drink_item(int option) {
    //each item is the same price, so one number is returned
    return 2.99;
  }


}
