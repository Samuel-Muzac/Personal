/* Each restaurant has three food items to
choose from and two drinks to choose


 */
public interface Restuarantmenu {


  void print_menu();

  double get_food_item(int option);

  double get_drink_item(int option);




}
