/* Class for &pizza that lists its menu and prices
* &pizza serves stirfry food
 */

public class Pizza implements Restuarantmenu{


  @Override
  public void print_menu() {
    System.out.println("      Entrees      ");
    System.out.println("**Press the number associated with the item");
    System.out.println("1. Dirty Bird: parm-romano sauce, " +
            "shredded mozzarella, " + "chicken, jalapeno pepper, " +
            "buffalo sauce, ranch dressing, crumbled blue cheese ($12.99)");
    System.out.println("2. 3Peat: classic sauce, shredded mozzarella, pepperoni" +
            ", italian sausage, bacon (($12.99)");
    System.out.println("3. White: parm-romano sauce, fresh mozzarella, " +
            "special T sauce, truffle ranch, cracked black pepper (($12.99)");
    System.out.println("      Drinks      ");
    System.out.println("4. &Tea Moody Meyer Lemon ($2.75");
    System.out.println("5. &Soda Sweet Root Beer ($2.75");

  }

  @Override
  public double get_food_item(int option) {
    //each item is the same price, so one number is returned
    return 12.99;
  }

  @Override
  public double get_drink_item(int option) {
    //each item is the same price, so one number is returned
    return 2.75;
  }


}
